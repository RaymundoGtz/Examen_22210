package com.example.alumnlisttarea4.viewmodels

import com.example.alumnlisttarea4.R
import com.example.alumnlisttarea4.models.Card

class AlumnViewModels {
    init {}

    fun getAlumnList(): ArrayList<Card> {
        var cardList: ArrayList<Card> = ArrayList<Card>()

        //Create list
        cardList.add(Card("#1", "Adivina la edad",R.drawable.pastel))
        cardList.add(Card("#2", "Gatos",R.drawable.gato))
        cardList.add(Card("#3", "NBA",R.drawable.nba))
        cardList.add(Card("#4", "Chuck Norris", R.drawable.chuck))



        return cardList
    }
}