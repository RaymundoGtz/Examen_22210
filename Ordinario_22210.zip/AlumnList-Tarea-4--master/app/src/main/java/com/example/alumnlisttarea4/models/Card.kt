package com.example.alumnlisttarea4.models

import androidx.annotation.DrawableRes

data class Card (
    val numero: String,
    val titulo: String,
    @DrawableRes val profilePic: Int,
)

