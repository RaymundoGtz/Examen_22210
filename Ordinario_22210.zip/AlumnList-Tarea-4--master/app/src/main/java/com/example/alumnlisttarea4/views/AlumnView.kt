package com.example.alumnlisttarea4.views

import androidx.compose.animation.expandHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.alumnlisttarea4.R
import java.util.Calendar

@Composable
fun AlumnView(
    navController: NavHostController,
    message: String,
    mensaje: String,
) {
    // State to store the input age
    val age = remember { mutableStateOf("") }
    // State to store the calculated year of birth
    val nacimiento = remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(15.dp),

    ) {
        Spacer(modifier = Modifier.height(15.dp))

        Column(
            modifier = Modifier
                .background(Color(0xffffffff), shape = RoundedCornerShape(15.dp))
                .padding(15.dp)
        ) {
            Text(
                modifier = Modifier.padding(top = 20.dp, start = 55.dp),
                text = "Introduce tu anyo de nacimiento",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )

            Spacer(modifier = Modifier.height(5.dp))

            TextField(
                value = age.value,
                onValueChange = { age.value = it },
                label = { Text("Introduce tu edad") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 5.dp)
            )

            Spacer(modifier = Modifier.height(15.dp))

            Button(
                onClick = {
                    val edad = Calendar.getInstance().get(Calendar.YEAR)
                    val anyoactual = age.value.toIntOrNull()
                    if (edad != null) {
                        if (anyoactual != null) {
                            nacimiento.value = (anyoactual - edad).toString()
                        }
                    } else {
                        nacimiento.value = "Entrada inválida"
                    }
                },
                colors = ButtonDefaults.buttonColors(Color(0xFF2196F3)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Calcular año de nacimiento",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFFFFF),
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(15.dp))


        }
        Text(modifier = Modifier.padding(top = 170.dp, start = 50.dp),

            text = "Año de nacimiento: ${nacimiento.value}",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = Color(0xFF673AB7),


            )

        Button(
            onClick = { navController.currentBackStackEntry },
            colors = ButtonDefaults.buttonColors(Color(0xFF2196F3)),
            modifier = Modifier
                .padding(horizontal = 5.dp)
                .padding(top = 150.dp)
        ) {
            Text(modifier = Modifier.padding(10.dp),
                text = "<-",
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFFFFF),
                fontSize = 20.sp
            )
        }

    }




}

@Preview(showBackground = true)
@Composable
fun Preview_Alumn() {
    AlumnView(
        navController = rememberNavController(),
        message = "Introduce el anyo de nacimiento",
        mensaje = "Introduce el anyo de nacimiento",
    )
}
