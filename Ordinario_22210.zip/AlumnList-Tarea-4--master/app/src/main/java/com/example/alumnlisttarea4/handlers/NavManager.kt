package com.example.alumnlisttarea4.handlers

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.alumnlisttarea4.views.AlumnView
import com.example.alumnlisttarea4.views.ListView

@Composable
fun NavManager() {
    var navController: NavHostController = rememberNavController()
    NavHost(navController = navController, startDestination = "ListView") {

        //Definiendo Rutas
        composable(route = "ListView") {
            ListView(navController)
        }

        composable(route = "AlumnView" +
                            "/{message}" +
                            "/{id}" +
                            "/{name}" +
                            "/{mail}" +
                            "/{semester}" +
                            "/{career}" +
                            "/{hasScolarship}" +
                            "/{gpa}" +
                            "/{soldTickets}" +
                            "/{profilePic}",

                    arguments =
                        listOf(
                            navArgument("message") {type = NavType.StringType},
                            navArgument("id") {type = NavType.IntType},

                        )
        ) {
            parameters ->
                val message = parameters.arguments?.getString("message") ?: ""


            AlumnView(
                navController,
                message,
                mensaje = ""
            )
        }
    }
}